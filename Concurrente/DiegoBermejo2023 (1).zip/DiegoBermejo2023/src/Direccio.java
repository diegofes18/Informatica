//Possibles direccions del cotxes
public enum Direccio {NORD, SUD}
