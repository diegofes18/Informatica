/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Parking;

import static java.lang.Thread.sleep;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author Jaume
 */
public class VigilantMonitor {

    private final int MAX = 5;
    private final int BARRERES;
    private final Lock lock = new ReentrantLock();
    private Condition canEnter;
    private Condition canExit;
    private int places;//nombre cotxes dins el parking
    private int barreresTancades;
    public boolean parkingTancat=false;

    public VigilantMonitor(int n) {
        canEnter = lock.newCondition();
        canExit = lock.newCondition();
        places = 0;
        barreresTancades = 0;
        BARRERES = n;
    }

    public int aixecaBarrera() {
        lock.lock();
        try {
            //mentre ple
            while (places >= MAX) {
                canEnter.await();
            }
            places++;
            canExit.signal();
            return places;
        } catch (Exception e) {
        } finally {
            lock.unlock();
        }
        return -1;
    }

    public int aixecaSortida() {
        lock.lock();
        try {
                //mentre buit
                while (places == 0) {
                    System.out.println("Barrera bloquetjada");
                    canExit.await();
                }
                if(!this.parkingTancat){
                places--;
                if(places==MAX-1){
                    canEnter.signal();
                }
                return places;
                }else{
                    return -1;
                }
            
        } catch (Exception e) {
        } finally {
            lock.unlock();
        }

        return -1;
    }
     public boolean isParkingTancat(){
        return this.parkingTancat;
    }
    public void apagaBarrera() {
        lock.lock();
        try {
            this.barreresTancades++;
        if (this.barreresTancades == BARRERES) {
            System.out.println("++++++++++ El parking tanca. A dins han quedat: " + places + " cotxes");
            parkingTancat=true;
            canExit.signalAll();
        }
        } catch (Exception e) {
        }finally{
            lock.unlock();
        }
        
    }

}
