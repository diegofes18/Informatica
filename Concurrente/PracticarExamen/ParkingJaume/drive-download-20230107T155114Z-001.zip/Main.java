/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Parking;

import java.util.Random;

/**
 *
 * @author Jaume
 */
public class Main {
    private static final int BarreresEntrada = 3;
    private static final int BarreresSortida = 2;
    public static final VigilantMonitor monitor = new VigilantMonitor(BarreresEntrada);

    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        Random rand=new Random();
        int t=0;
        Thread[] threads = new Thread[BarreresEntrada + BarreresSortida];
        
        //init barreresEntrada
        for (int i = 0; i < BarreresEntrada + 1; i++) {
            threads[i] = new Thread(new BarreraEntrada(t, rand.nextInt(10)));
            t++;
        }
        t=0;
        //init barreresSortida
        for (int i = BarreresEntrada; i < BarreresEntrada + BarreresSortida; i++) {
            threads[i] = new Thread(new BarreraSortida(t));
            t++;
        }
        for (int i = 0; i < BarreresSortida+BarreresEntrada; i++) {
            threads[i].start();
        }
        for (int i = 0; i < threads.length; i++) {
            threads[i].join();
        }
    }

}
