/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Parking;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jaume
 */
public class BarreraEntrada implements Runnable{
    private final int id;
    private final int n;
    private int counter;

    public BarreraEntrada(int id, int n) {
        this.id = id;
        this.n = n;
        counter=0;
    }
    

    @Override
    public void run() {
        System.out.println("Barrera d'entrada E"+id+" ON");
        System.out.println("Barrera d'entrada E"+id+" es preveuen "+n+" entrades");
        for (int i = 0; i < n; i++) {
            try {
                Thread.sleep(1000);
                int n=Main.monitor.aixecaBarrera();
                counter++;
                System.out.println("********** Barrera: E"+id+" # Entrades: "+counter+"  /  Places Ocupades: "+n);
            } catch (InterruptedException ex) {
                Logger.getLogger(BarreraEntrada.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println("Barrea d'entrada E"+id+" OFF");
        Main.monitor.apagaBarrera();
    }
}
