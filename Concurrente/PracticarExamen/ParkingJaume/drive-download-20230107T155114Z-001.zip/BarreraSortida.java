/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Parking;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jaume
 */
public class BarreraSortida implements Runnable {

    private final int id;
    private int counter;

    public BarreraSortida(int id) {
        this.id = id;
        counter = 0;
    }

    @Override
    public void run() {
        System.out.println("        Barrera de sortida S" + id + " ON");
        boolean end = false;

        while (!Main.monitor.isParkingTancat()) {
            try {
                Thread.sleep(3000);
                int n = Main.monitor.aixecaSortida();
                if (n != -1) {
                    counter++;
                    System.out.println("---------- Barrera: S" + id + " # Sortides: " + counter + "  /  Places Ocupades: " + n);
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(BarreraSortida.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        System.out.println("            Barrera de sortida S" + id + " OFF");
    }
}
