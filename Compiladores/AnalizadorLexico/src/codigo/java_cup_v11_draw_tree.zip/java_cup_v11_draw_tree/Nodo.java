
public class Nodo {
	
	String valore;
	double posX;
	double posY;

	public Nodo(String string, double i, double j) {
		valore=string;
		posX=i;
		posY=j;
	}

	
	
}
